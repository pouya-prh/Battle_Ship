#ifndef HASHPASSWORD_H
#define HASHPASSWORD_H
#include <QString>
class HashPassword
{
public:
    HashPassword();
    static void Hash(QString&);
};

#endif // HASHPASSWORD_H
